import React from 'react';
import {
  BarChart3,Users,Store,ClipboardCheck,CreditCard,Package,ShoppingCart,
  MessageSquare,Bell,Tags,Star,Flag,Settings,ChevronRight,ArrowLeft,
  RefreshCw,Search,Check, XCircle, Eye
} from 'lucide-react';

const sections=[
 ['overview','Overview',BarChart3,'Marketplace performance and pending work'],
 ['users','Users',Users,'Manage registered buyers and accounts'],
 ['sellers','Sellers',Store,'Manage seller accounts and status'],
 ['applications','Applications',ClipboardCheck,'Review and approve seller applications'],
 ['payments','Payments',CreditCard,'Verify UGX 15,000 seller payments'],
 ['listings','Listings',Package,'Review, approve and manage listings'],
 ['orders','Orders',ShoppingCart,'Monitor marketplace orders'],
 ['messages','Messages & reports',MessageSquare,'Review conversations and reported issues'],
 ['notifications','Notifications',Bell,'View platform notifications'],
 ['categories','Categories',Tags,'Marketplace categories'],
 ['reviews','Reviews',Star,'Review marketplace feedback'],
 ['reports','Reports',Flag,'Investigate reported users and listings'],
 ['settings','Platform settings',Settings,'Marketplace configuration']
];

const tables={users:'profiles',sellers:'sellers',applications:'sellers',payments:'sellers',listings:'listings',orders:'orders',messages:'messages',notifications:'notifications',reviews:'reviews',reports:'reports',categories:'categories'};

export default function AdminDashboard({fm,go,notify}){
 const [active,setActive]=React.useState('overview');
 const [stats,setStats]=React.useState({});
 const [rows,setRows]=React.useState([]);
 const [loading,setLoading]=React.useState(false);
 const [query,setQuery]=React.useState('');
 const current=sections.find(x=>x[0]===active)||sections[0]; const CurrentIcon=current[2];

 const loadStats=React.useCallback(async()=>{
   const keys=['users','sellers','listings','orders','notifications','reports','reviews'];
   const out={};
   await Promise.all(keys.map(async k=>{
     const {count}=await fm.from(tables[k]).select('*',{count:'exact',head:true});
     out[k]=count||0;
   }));
   const {count:pending}=await fm.from('sellers').select('*',{count:'exact',head:true}).in('status',['pending','submitted']);
   const {count:payments}=await fm.from('sellers').select('*',{count:'exact',head:true}).eq('activation_payment_status','pending');
   out.pending=pending||0;out.payments=payments||0;
   setStats(out);
 },[fm]);

 const loadRows=React.useCallback(async(id)=>{
   if(!tables[id]){setRows([]);return}
   setLoading(true);
   let q=fm.from(tables[id]).select('*').order('created_at',{ascending:false}).limit(100);
   if(id==='applications')q=q.in('status',['pending','submitted']);
   if(id==='payments')q=q.eq('activation_payment_status','pending');
   const r=await q;
   setRows(r.data||[]);
   setLoading(false);
 },[fm]);

 React.useEffect(()=>{loadStats()},[loadStats]);
 React.useEffect(()=>{if(active!=='overview')loadRows(active)},[active,loadRows]);

 const refresh=()=>{loadStats();if(active!=='overview')loadRows(active);notify('Admin data refreshed')};
 const choose=id=>setActive(id);

 return <section className="adminPage">
   <div className="adminHero">
     <div><span>FARMMARKET UGANDA · CONTROL CENTRE</span><h1>Super Admin</h1><p>Manage the marketplace from one protected workspace.</p></div>
     <button className="adminHeroBtn" onClick={()=>go('dashboard')}><ArrowLeft/> My account</button>
   </div>

   <div className="adminStats">
     <Stat n={stats.users??'—'} t="Users"/><Stat n={stats.sellers??'—'} t="Sellers"/>
     <Stat n={stats.listings??'—'} t="Listings"/><Stat n={stats.orders??'—'} t="Orders"/>
     <Stat n={stats.pending??'—'} t="Pending sellers"/><Stat n={stats.payments??'—'} t="Pending payments"/>
   </div>

   <div className="adminShell">
     <aside className="adminSidebar">{sections.map(([id,title,I])=>
       <button className={active===id?'selected':''} key={id} onClick={()=>choose(id)}><I/><span>{title}</span><ChevronRight/></button>)}</aside>

     <div className="adminMain">
       <div className="adminSectionHead">
         <div><CurrentIcon/><span>ADMINISTRATION</span><h2>{current[1]}</h2><p>{current[3]}</p></div>
         <button className="adminBack" onClick={refresh}><RefreshCw/> Refresh</button>
       </div>

       {active==='overview'
        ? <Overview stats={stats} choose={choose}/>
        : <Management id={active} title={current[1]} rows={rows} loading={loading} query={query} setQuery={setQuery} refresh={refresh} notify={notify}/>
       }
     </div>
   </div>

   <nav className="adminMobileNav">{sections.slice(0,5).map(([id,title,I])=>
     <button className={active===id?'active':''} key={id} onClick={()=>choose(id)}><I/><small>{title}</small></button>)}</nav>
 </section>
}

function Stat({n,t}){return <div className="adminStat"><b>{n}</b><span>{t}</span></div>}

function Overview({stats,choose}){
 return <><div className="adminQuick">
   <Quick title="Seller applications" value={stats.pending??0} text="Waiting for review" id="applications" choose={choose}/>
   <Quick title="Payment verification" value={stats.payments??0} text="UGX 15,000 applications" id="payments" choose={choose}/>
   <Quick title="Listings" value={stats.listings??0} text="Marketplace listings" id="listings" choose={choose}/>
   <Quick title="Reports" value={stats.reports??0} text="Issues requiring attention" id="reports" choose={choose}/>
 </div>
 <div className="adminActivity"><h3>Administration centre</h3><p>Every major marketplace operation has its own workspace. Choose a section to review records and take action.</p>
   <div className="adminFeatureGrid">{sections.slice(1).map(([id,title,I,text])=>
     <button key={id} onClick={()=>choose(id)}><I/><div><b>{title}</b><span>{text}</span></div><ChevronRight/></button>)}</div>
 </div></>
}
function Quick({title,value,text,id,choose}){return <button className="adminQuickCard" onClick={()=>choose(id)}><span>{title}</span><strong>{value}</strong><small>{text}</small><ChevronRight/></button>}

function Management({id,title,rows,loading,query,setQuery,refresh,notify}){
 const filtered=rows.filter(r=>JSON.stringify(r).toLowerCase().includes(query.toLowerCase()));
 const approve=async(row)=>{
   if(id==='applications'||id==='sellers'){
     const r=await notifyUpdate(fm,row,'status','approved',notify); if(r)return;
   } else if(id==='payments'){
     const r=await notifyUpdate(fm,row,'activation_payment_status','verified',notify); if(r)return;
   } else if(id==='listings'){
     const r=await notifyUpdate(fm,row,'status','approved',notify); if(r)return;
   }
   refresh();
 };
 const reject=async(row)=>{
   if(id==='applications'||id==='sellers')await notifyUpdate(fm,row,'status','rejected',notify);
   else if(id==='payments')await notifyUpdate(fm,row,'activation_payment_status','rejected',notify);
   else if(id==='listings')await notifyUpdate(fm,row,'status','rejected',notify);
   refresh();
 };
 const actionable=['applications','sellers','payments','listings'].includes(id);
 return <div className="adminManagement">
   <div className="adminToolbar"><div className="adminSearch"><Search/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={`Search ${title.toLowerCase()}…`}/></div><button className="adminRefresh" onClick={refresh}><RefreshCw/> Refresh</button></div>
   {loading?<div className="adminLoading">Loading records…</div>:filtered.length===0?<div className="adminEmptyIcon"><Eye/><h3>No records found</h3><p>There are no matching records in this section yet.</p></div>:
   <div className="adminTableWrap"><table><thead><tr><th>Record</th><th>Status</th><th>Created</th>{actionable&&<th>Action</th>}</tr></thead><tbody>
   {filtered.map(row=><tr key={row.id}><td><b>{labelFor(id,row)}</b><small>{row.id}</small></td><td><span className={`adminStatus ${String(row.status||row.activation_payment_status||'active').toLowerCase()}`}>{row.activation_payment_status||row.status||'active'}</span></td><td>{row.created_at?new Date(row.created_at).toLocaleDateString():'—'}</td>{actionable&&<td><div className="adminRowActions"><button onClick={()=>approve(row)}><Check/> Approve</button><button onClick={()=>reject(row)}><XCircle/> Reject</button></div></td>}</tr>)}
   </tbody></table></div>}
 </div>
}

function labelFor(id,r){
 return r.farm_name||r.title||r.full_name||r.email||r.name||r.subject||r.category||`${id} record`;
}
async function notifyUpdate(fm,row,column,value,notify){
 try{
   const r=await fm.from(currentTable(row,column)).update({[column]:value}).eq('id',row.id);
   if(r.error){notify(r.error.message);return r.error}
   notify(`Updated to ${value}`);return null;
 }catch(e){notify(e.message);return e}
}
function currentTable(row,column){
 if(column==='activation_payment_status'||column==='status') return row.farm_name!==undefined?'sellers':row.title!==undefined?'listings':'profiles';
 return 'profiles';
}
